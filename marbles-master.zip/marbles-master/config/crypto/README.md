# Drop your admin keys/certs in this folder.
This is used for install and instantiate.

## Private Key:
- Contents should include `-----BEGIN PRIVATE KEY-----` and `-----END PRIVATE KEY-----`

## Certificate:
- Contents should include `-----BEGIN CERTIFICATE-----` and `-----END CERTIFICATE-----`
